<?php

require_once dirname(dirname(__FILE__)) . '/deal/getfields.class.php';

return 'modB24CRMDealFieldsGetListProcessor';