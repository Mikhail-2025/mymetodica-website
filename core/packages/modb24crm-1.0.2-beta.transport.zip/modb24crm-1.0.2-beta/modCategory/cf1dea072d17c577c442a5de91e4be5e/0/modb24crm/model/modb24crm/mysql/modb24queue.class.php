<?php
require_once (dirname(__DIR__) . '/modb24queue.class.php');
class modB24Queue_mysql extends modB24Queue {}