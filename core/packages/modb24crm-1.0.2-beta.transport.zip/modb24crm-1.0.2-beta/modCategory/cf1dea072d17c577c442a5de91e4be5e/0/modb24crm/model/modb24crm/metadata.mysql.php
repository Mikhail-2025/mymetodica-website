<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'modB24Account',
    1 => 'modB24FIHook',
    2 => 'modB24Queue',
  ),
  'xPDOObject' => 
  array (
    0 => 'modB24Link',
    1 => 'modB24Field',
  ),
);