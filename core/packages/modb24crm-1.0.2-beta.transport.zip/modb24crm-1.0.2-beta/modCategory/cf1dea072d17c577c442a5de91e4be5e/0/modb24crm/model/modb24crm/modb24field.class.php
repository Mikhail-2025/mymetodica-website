<?php
class modB24Field extends xPDOObject {}