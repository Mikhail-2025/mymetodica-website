<?php

class modB24HandlerUpdateProcessor extends modObjectUpdateProcessor
{
    /** @var modB24Handler $object */
    public $object;
    public $classKey = 'modB24Handler';
    public $languageTopics = array('modb24crm');
    //public $permission = '';


    /**
     * @return bool|null|string
     */
    public function initialize()
    {
        if (!$this->modx->hasPermission($this->permission)) {
            return $this->modx->lexicon('access_denied');
        }

        return parent::initialize();
    }


    /**
     * @return bool
     */
    public function beforeSet()
    {
        $required = array('key','handler');
        foreach ($required as $field) {
            if (!$tmp = trim($this->getProperty($field))) {
                $this->addFieldError($field, $this->modx->lexicon('field_required'));
            } else {
                $this->setProperty($field, $tmp);
            }
        }

        return !$this->hasErrors();
    }

}

return 'modB24HandlerUpdateProcessor';