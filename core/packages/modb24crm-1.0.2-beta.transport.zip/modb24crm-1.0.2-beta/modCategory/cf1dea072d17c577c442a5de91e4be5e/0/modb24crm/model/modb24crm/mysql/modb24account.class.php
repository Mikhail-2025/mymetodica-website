<?php
require_once (dirname(__DIR__) . '/modb24account.class.php');
class modB24Account_mysql extends modB24Account {}