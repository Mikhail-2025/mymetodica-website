<?php

$_lang['modb24crm_prop_modB24CRMHook'] = 'ID или название хука';