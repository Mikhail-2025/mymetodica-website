--------------------
modB24CRM
--------------------
Author: Artem Nizovskikh <nizart91@gmail.com>
--------------------

Module integration of the site on MODx Revolution and Bitrix24