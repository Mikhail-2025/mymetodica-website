<?php

$_lang['area_modb24crm_main'] = 'Основные';

//$_lang['setting_modb24crm_some_setting'] = 'Какая-то настройка';
//$_lang['setting_modb24crm_some_setting_desc'] = 'Это описание для какой-то настройки';