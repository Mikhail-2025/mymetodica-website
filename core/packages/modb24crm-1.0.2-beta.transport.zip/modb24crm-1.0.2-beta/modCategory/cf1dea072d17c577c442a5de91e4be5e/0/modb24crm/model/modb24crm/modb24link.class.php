<?php
class modB24Link extends xPDOObject {}