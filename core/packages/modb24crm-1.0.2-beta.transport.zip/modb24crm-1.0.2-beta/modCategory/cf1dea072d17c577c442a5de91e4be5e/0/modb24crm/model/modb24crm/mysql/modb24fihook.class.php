<?php
require_once (dirname(__DIR__) . '/modb24fihook.class.php');
class modB24FIHook_mysql extends modB24FIHook {}