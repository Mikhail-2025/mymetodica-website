<?php
require_once (dirname(__DIR__) . '/modb24link.class.php');
class modB24Link_mysql extends modB24Link {}