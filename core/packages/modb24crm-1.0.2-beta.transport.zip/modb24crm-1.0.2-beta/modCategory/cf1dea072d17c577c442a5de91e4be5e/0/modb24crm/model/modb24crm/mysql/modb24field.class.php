<?php
require_once (dirname(__DIR__) . '/modb24field.class.php');
class modB24Field_mysql extends modB24Field {}